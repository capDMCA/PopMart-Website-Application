import { OrderItem } from './orderItem';

describe('OrderItem', () => {
  it('should create an instance', () => {
    expect(new OrderItem()).toBeTruthy();
  });
});
