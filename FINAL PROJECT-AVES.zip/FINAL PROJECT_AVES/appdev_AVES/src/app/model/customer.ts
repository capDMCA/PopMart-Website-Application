export class Customer {
    //Login Details
   id : number = 0;
   customerId : number = 0;
   customerEmail : string = '';
   customerUsername : string = '';
   customerPassword : string = '';

   //Personal Details
   firstname : string = '';
   middlename : string = '';
   lastname: string = '';
   dateOfBirth : string = '';
   gender : string = '';
   phoneNumber : string = '';
   Address : string = '';
    
}

