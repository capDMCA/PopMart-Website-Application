import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Product } from '../model/product';
import { ProductCategory } from '../model/product-category';
import { ProductService } from '../service/product.service';
import { CartService } from '../service/cart.service'; 
import { OrderItem } from '../model/orderItem';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css']
})
export class ProductCategoryComponent implements OnInit {
  public productsCategory: ProductCategory[] = [];
  public cartItems: OrderItem[] = [];
  public quantities: { [productId: number]: number } = {};
  
  public notificationVisible = false;
  public notificationMessage = '';
  public customerId: number = 0; 
  public customerName: string | null = null;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private cdr: ChangeDetectorRef,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.productService.getData().subscribe(data => { 
      this.productsCategory = data; 
  
      if (this.authService.isLoggedIn()) {
        this.customerId = Number(this.authService.getCurrentCustomerId()) || 0;
        this.customerName = this.authService.getCurrentUsername();
      } else {
        this.customerId = 0;
        this.customerName = "Guest";
      }
    });

    this.cartService.findAll().subscribe((data: OrderItem[]) => {
      this.cartItems = data.filter((item: OrderItem) => item.customerId === this.customerId);
      this.cartItems.forEach(item => this.quantities[item.productId] = item.quantity);
    });
  }

  addToCart(product: Product): void {
    const existingItem = this.getCartItem(product.id);

    const quantity = this.quantities[product.id] || 1;
    if (existingItem) {
      if (existingItem.quantity !== quantity) {
        const updatedItem: OrderItem = { ...existingItem, quantity };
        const itemId = existingItem.id ?? 0;
        
        this.cartService.putUpdate(itemId, updatedItem).subscribe(response => {
          this.cartItems = this.cartItems.map(item => item.id === itemId ? response : item);
          this.showNotification('Item quantity updated in cart!');
        }, error => {
          console.error('Error updating cart item:', error);
        });
      }
    } else {
      const newItem: OrderItem = {
        customerId: this.customerId,
        customerName: this.customerName || "",
        productId: product.id,
        productName: product.name,
        imageFile: product.imageFile,
        quantity,
        price: product.price,
        uom: product.unitOfMeasure,
        status: 'In-Cart'
      };

      this.cartService.addItemToCart(newItem).subscribe(response => {
        this.cartItems.push(response);
        this.showNotification('Item added to cart!');
      }, error => {
        console.error('Error adding item to cart:', error);
      });
    }
  }

  private showNotification(message: string): void {
    this.notificationMessage = message;
    this.notificationVisible = true;

    setTimeout(() => {
      this.notificationVisible = false;
    }, 2000);
  }

  increaseQuantity(product: Product): void {
    this.quantities[product.id] = (this.quantities[product.id] || 0) + 1;
  }

  decreaseQuantity(product: Product): void {
    if (this.quantities[product.id] > 1) {
      this.quantities[product.id] -= 1;
    }
  }

  removeFromCart(product: Product): void {
    const itemIndex = this.cartItems.findIndex(item => item.productId === product.id);
    
    if (itemIndex !== -1) {
      const itemId = this.cartItems[itemIndex].id;
      if (itemId !== undefined) {
        this.cartService.removeItemFromCart(itemId).subscribe(() => {
          this.cartItems.splice(itemIndex, 1);
          this.showNotification(`${product.name} has been removed from your cart.`);
        }, error => {
          console.error('Error removing item from cart:', error);
        });
      } else {
        console.error('Item ID is undefined. Cannot remove item from cart.');
      }
    }
  }

  isProductInCustomerCart(productId: number): boolean {
    return this.cartItems.some(item => item.productId === productId);
  }

  private getCartItem(productId: number): OrderItem | undefined {
    return this.cartItems.find(item => item.productId === productId);
  }
}
