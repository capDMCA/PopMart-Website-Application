import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../model/customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm!: FormGroup;

  constructor(private fb: FormBuilder,
     private customerService: CustomerService,
     private router: Router
    
    
    ) {}

  ngOnInit() {
    this.signupForm = this.fb.group({
      customerEmail: ['', [Validators.required, Validators.email]],
      customerUsername: ['', [Validators.required]],
      customerPassword: ['', [Validators.required]],
      firstname: ['', [Validators.required]],
      middlename: [''],
      lastname: ['', [Validators.required]],
      dateOfBirth: ['', [Validators.required]],
      phoneNumber: ['', [Validators.required]],
      address: ['', [Validators.required]],
      gender: ['', [Validators.required]],
    });
  }

  private generateUniqueCustomerId(): number {
    // tinamad ako gumawa ng post method na nag gegenerate ng unique ID para sa customer kaya eto lang muna -raf
    // Bahala na si lord, sana hindi mag generate ng duplicate ID 1/1000000 chance
    return Math.floor(Math.random() * 1000000); 
  }

  onSignup() {
    if (this.signupForm.valid) {
      const customer: Customer = { ...this.signupForm.value, customerId: this.generateUniqueCustomerId() }; 
  
      this.customerService.add(customer).subscribe(
        response => {
          console.log('Customer created successfully:', customer);
          console.log('Customer ID set:', customer.customerId);
          //Redirect to login page
          this.router.navigate(['/signin']);


        },
        error => {
          console.error('Error creating customer:', error);
        }
      );
    } else {
      console.log('Form is invalid');
    }
  }
}
