import { Component, OnInit } from '@angular/core';
import { ProductService } from '../service/product.service';
import { AuthService } from '../service/auth.service';
import { ProductCategory } from '../model/product-category';

@Component({
  selector: 'app-main-body',
  templateUrl: './main-body.component.html',
  styleUrls: ['./main-body.component.css']
})
export class MainBodyComponent {
  products = [
    { name: 'Product 1', imageFile: 'assets/products/kda.jpeg', description: 'League of Legends KDA', price: 200.00 },
    { name: 'Product 2', imageFile: 'assets/products/witch.jpeg', description: 'PEACHRIOT WITCHY PUNK', price: 200.00},
    { name: 'Product 3', imageFile: 'assets/products/mollybear.jpeg', description: 'MOLLYBEAR 1/8 ACTION FIGURE', price: 200.00 },
    { name: 'Product 4', imageFile: 'assets/products/snowman.jpeg', description: 'HACIPUPU ACTION FIGURE', price: 200.00 },
    // Add more products as needed
  ];

  currentSlide = 0;

  nextSlide() {
    this.currentSlide = (this.currentSlide + 1) % this.products.length;
    this.updateCarouselPosition();
  }

  prevSlide() {
    this.currentSlide = (this.currentSlide - 1 + this.products.length) % this.products.length;
    this.updateCarouselPosition();
  }

  updateCarouselPosition() {
    const track = document.querySelector('.carousel-track') as HTMLElement;
    track.style.transform = `translateX(-${this.currentSlide * 300}px)`;
  }
}