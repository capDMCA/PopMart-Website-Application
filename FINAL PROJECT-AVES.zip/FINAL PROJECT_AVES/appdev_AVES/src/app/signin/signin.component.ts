import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  signinForm!: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private customerService: CustomerService,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.signinForm = this.fb.group({
      customerEmail: ['', [Validators.required, Validators.email]],
      customerPassword: ['', [Validators.required]],
    });
  }

  onSignin() {
   this.authService.signIn(this.signinForm.value.customerEmail, this.signinForm.value.customerPassword)
      .subscribe(
        () => {
          this.router.navigate(['/']).then(() => {
            // Force reload after navigation
            window.location.reload();
          });
        },
        error => {
          this.errorMessage = error.message;
        }
      );
  }
}
