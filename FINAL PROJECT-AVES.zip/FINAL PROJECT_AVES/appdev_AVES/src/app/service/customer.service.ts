import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';
import { BaseHttpService } from './base-http.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService extends BaseHttpService {
  
  constructor(http: HttpClient) {
    super(http, '/api/customer');
  }

  // Method to add a new customer
  addCustomer(customer: Customer): Observable<Customer> {
    return this.add(customer); // Calls the inherited add method
  }

  getCustomerById(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${id}`);
  }

  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(`${this.baseUrl}/customers`);
  }


  signIn(email: string, password: string): Observable<any> {
    const loginData = { email, password };
    return this.add(loginData); 
  }
}
