import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { HttpClient } from '@angular/common/http';
import { Order } from '../model/order';
import { Observable } from 'rxjs'; // Import Observable from rxjs
import { map, tap } from 'rxjs/operators'; // Import map and tap operators

@Injectable({
  providedIn: 'root'
})
export class OrderService extends BaseHttpService {
  private orders: Order[] = []; // Local state for orders

  constructor(protected override http: HttpClient) { 
    super(http, '/api/order');
  }

  saveOrder(order: Order): Observable<Order> {
    return this.http.post<Order>(this.baseUrl, order);
  }

  getOrdersByCustomerId(customerId: string | null): Observable<Order[]> {
    return this.http.get<Order[]>(this.baseUrl).pipe(
      map((orders: Order[]) => {
        this.orders = orders.filter(order => order.customerId.toString() === customerId);
        return this.orders;
      })
    );
  }

  // Method to delete an order and update local state
  removeOrder(orderId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${orderId}`).pipe(
      tap(() => {
        // Update local state by filtering out the deleted order
        this.orders = this.orders.filter(order => order.id !== orderId);
        // Optionally, you might want to do additional updates like recalculating totals, etc.
        // e.g., this.calculateTotalAmount();
      })
    );
  }
}
