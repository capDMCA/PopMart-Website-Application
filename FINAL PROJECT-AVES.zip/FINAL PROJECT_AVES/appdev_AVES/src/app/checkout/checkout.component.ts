import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { OrderService } from '../service/order.service';
import { AuthService } from '../service/auth.service';
import { Router, NavigationStart } from '@angular/router';
import { Order } from '../model/order';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit, OnDestroy {
  public orders: Order[] = [];
  private currentCustomerId: string | null = null;
  totalAmount: number = 0;
  private routerSubscription!: Subscription; // To hold the subscription for router events

  constructor(
    private orderService: OrderService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentCustomerId = this.authService.getCurrentCustomerId();
    console.log('Current customer ID:', this.currentCustomerId);
    this.loadOrders();

    // Subscribe to router events to listen for navigation
    this.routerSubscription = this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        // Show warning before navigating away
        const confirmLeave = window.confirm('You have unsaved changes. Do you really want to leave?');
        if (!confirmLeave) {
          // If the user cancels, prevent navigation
          this.router.navigate(['/checkout']); // Redirect back to checkout or use any other logic
          return;
        }
        // If confirmed, proceed to delete orders
        this.deleteOrders(); // Call deleteOrders when navigating away
      }
    });
  }

  ngOnDestroy(): void {
    // Clean up subscription to prevent memory leaks
    this.routerSubscription.unsubscribe();
  }

  private loadOrders(): void {
    // Fetch orders belonging to the current customer
    this.orderService.getOrdersByCustomerId(this.currentCustomerId).subscribe({
      next: (data: Order[]) => {
        // Filter orders by the customer ID and the status "Check-out-in-progress"
        this.orders = data.filter(order => 
          order.customerId === Number(this.currentCustomerId) && 
          order.status === "Check-out-in-progress"
        );

        // Calculate the total amount after filtering
        this.calculateTotalAmount();
      },
      error: (error) => {
        console.error('Error fetching orders:', error);
      }
    });
  }

  // Warning when the user tries to refresh the page
  @HostListener('window:beforeunload', ['$event'])
  unloadNotification($event: any): void {
    $event.returnValue = 'Are you sure you want to cancel the checkout? All orders will be deleted.';
  }

  // Method to delete orders with status "Check-out-in-progress" for the current customer
  private deleteOrders(): void {
    // Filter orders to only delete those with status "Check-out-in-progress"
    const ordersToDelete = this.orders.filter(order => 
      order.customerId === Number(this.currentCustomerId) && 
      order.status === "Check-out-in-progress"
    );
  
    // Loop through filtered orders and delete them
    ordersToDelete.forEach(order => {
      if (order.id !== undefined) { // Ensure order.id is defined
        this.orderService.removeOrder(order.id).subscribe({
          next: () => {
            console.log(`Order with ID ${order.id} has been deleted.`);
          },
          error: (error) => {
            console.error('Error deleting order:', error);
          }
        });
      } else {
        console.error('Order ID is undefined for the order:', order);
      }
    });
  }

  // Method to handle checkout confirmation
  confirmOrder(): void {
    // Logic for confirming the order goes here
  }

  private calculateTotalAmount(): void {
    this.totalAmount = this.orders.reduce((sum, order) => sum + parseFloat(order.totalAmount), 0);
  }
}
