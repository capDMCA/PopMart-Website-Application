package com.aves.entity;

public class CatagoryData {
}
