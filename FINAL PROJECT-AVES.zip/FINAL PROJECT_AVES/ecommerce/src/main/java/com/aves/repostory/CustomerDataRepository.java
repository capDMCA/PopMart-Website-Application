package com.aves.repostory;

import com.aves.entity.CustomerData;
import org.springframework.data.repository.CrudRepository;

public interface CustomerDataRepository extends CrudRepository<CustomerData,Integer> {
}
