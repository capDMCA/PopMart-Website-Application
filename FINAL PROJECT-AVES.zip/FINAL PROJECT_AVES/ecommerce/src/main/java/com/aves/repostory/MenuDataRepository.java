package com.aves.repostory;

import com.aves.entity.MenuData;
import org.springframework.data.repository.CrudRepository;

public interface MenuDataRepository extends CrudRepository<MenuData,Integer> {
}
