package com.aves.repostory;

import com.aves.entity.OrderItemData;
import org.springframework.data.repository.CrudRepository;

public interface OrderItemDataRepository extends CrudRepository<OrderItemData, Integer> {

}
