package com.aves.entity;

public class AppDetailsData
{

}
