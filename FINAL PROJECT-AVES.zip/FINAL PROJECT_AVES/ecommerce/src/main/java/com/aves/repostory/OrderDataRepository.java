package com.aves.repostory;

import com.aves.entity.OrderData;
import org.springframework.data.repository.CrudRepository;

public interface OrderDataRepository extends CrudRepository<OrderData, Integer> {

}
