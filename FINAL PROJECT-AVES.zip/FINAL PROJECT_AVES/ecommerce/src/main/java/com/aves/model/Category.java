package com.aves.model;

public class Category {
    int id;
    String name;
    String description;
}
